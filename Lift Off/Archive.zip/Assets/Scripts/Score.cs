﻿public class Score{
	public static int gameScore = 0;
}
